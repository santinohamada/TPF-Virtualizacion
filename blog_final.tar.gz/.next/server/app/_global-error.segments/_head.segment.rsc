1:"$Sreact.fragment"
2:I[96237,["/_next/static/chunks/0t0g1zs8y3v_b.js","/_next/static/chunks/0q5gg26i4eeo2.js"],"ViewportBoundary"]
3:I[96237,["/_next/static/chunks/0t0g1zs8y3v_b.js","/_next/static/chunks/0q5gg26i4eeo2.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"nZoRGDxDValWljYEKVRKa"}

1:"$Sreact.fragment"
2:I[60379,["/_next/static/chunks/0t0g1zs8y3v_b.js","/_next/static/chunks/0q5gg26i4eeo2.js"],"default"]
3:I[44345,["/_next/static/chunks/0t0g1zs8y3v_b.js","/_next/static/chunks/0q5gg26i4eeo2.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"nZoRGDxDValWljYEKVRKa"}

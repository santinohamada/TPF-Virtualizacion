:HL["/_next/static/chunks/11unif--rw5h8.css","style"]
:HL["/_next/static/chunks/0fywy0v1.43o8.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"nZoRGDxDValWljYEKVRKa"}

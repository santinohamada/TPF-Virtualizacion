var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/posts/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__0zczg3u._.js")
R.c("server/chunks/_next-internal_server_app_api_posts_route_actions_0i2k_6m.js")
R.m(14649)
module.exports=R.m(14649).exports

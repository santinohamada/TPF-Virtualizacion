globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/nZoRGDxDValWljYEKVRKa/_buildManifest.js",
    "static/nZoRGDxDValWljYEKVRKa/_ssgManifest.js",
    "static/nZoRGDxDValWljYEKVRKa/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0je18qz9hnds_.js",
    "static/chunks/0p24o8.fhlw.v.js",
    "static/chunks/0nmpbnhzhmgto.js",
    "static/chunks/0rbhwvdsvh5it.js",
    "static/chunks/turbopack-03.53wh05slnd.js"
  ]
};

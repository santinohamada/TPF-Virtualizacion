1:"$Sreact.fragment"
2:I[39756,["https://tpf-virtualizacion.vercel.app/45275660/_next/static/chunks/0fsi8lw5utejl.js","https://tpf-virtualizacion.vercel.app/45275660/_next/static/chunks/0d3tkj33oycf2.js"],"default"]
3:I[37457,["https://tpf-virtualizacion.vercel.app/45275660/_next/static/chunks/0fsi8lw5utejl.js","https://tpf-virtualizacion.vercel.app/45275660/_next/static/chunks/0d3tkj33oycf2.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"3VTz5tohquaNx_PoWUqZS"}

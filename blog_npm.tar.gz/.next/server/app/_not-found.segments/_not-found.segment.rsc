1:"$Sreact.fragment"
2:I[39756,["/45275660/_next/static/chunks/0ya5kixflpvgt.js","/45275660/_next/static/chunks/0d3tkj33oycf2.js"],"default"]
3:I[37457,["/45275660/_next/static/chunks/0ya5kixflpvgt.js","/45275660/_next/static/chunks/0d3tkj33oycf2.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"L2YDzG75Y7fgnfDqK5ZX_"}

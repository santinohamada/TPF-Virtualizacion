:HL["https://tpf-virtualizacion.vercel.app/45275660/_next/static/chunks/06bzxzryt-_r5.css","style"]
:HL["https://tpf-virtualizacion.vercel.app/45275660/_next/static/chunks/0dlxeaqz_.2-9.css","style"]
:HL["https://tpf-virtualizacion.vercel.app/45275660/_next/static/media/797e433ab948586e-s.p.08e28id.o-okb.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["https://tpf-virtualizacion.vercel.app/45275660/_next/static/media/caa3a2e1cccd8315-s.p.09~u27dqhyhd6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"dCCayBmxQjGlgJPKJkW-k"}

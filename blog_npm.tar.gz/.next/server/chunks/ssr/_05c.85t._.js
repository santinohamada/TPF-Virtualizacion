module.exports=[48308,a=>{a.v("/_next/static/media/mi-foto.0rx9et~xbwhpn.jpeg"+(globalThis.NEXT_CLIENT_ASSET_SUFFIX||""))},33354,(a,b,c)=>{"use strict";c._=function(a){return a&&a.__esModule?a:{default:a}}}];

//# sourceMappingURL=_05c.85t._.js.map
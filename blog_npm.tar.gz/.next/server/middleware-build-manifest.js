globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/3VTz5tohquaNx_PoWUqZS/_buildManifest.js",
    "static/3VTz5tohquaNx_PoWUqZS/_ssgManifest.js",
    "static/3VTz5tohquaNx_PoWUqZS/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/02yc90psx--ft.js",
    "static/chunks/0cje14_narrpx.js",
    "static/chunks/0f31d~5_v8ll8.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/turbopack-00-1ysrpuemp~.js"
  ]
};

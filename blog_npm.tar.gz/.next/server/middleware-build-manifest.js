globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/L2YDzG75Y7fgnfDqK5ZX_/_buildManifest.js",
    "static/L2YDzG75Y7fgnfDqK5ZX_/_ssgManifest.js",
    "static/L2YDzG75Y7fgnfDqK5ZX_/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/02yc90psx--ft.js",
    "static/chunks/0cje14_narrpx.js",
    "static/chunks/0f31d~5_v8ll8.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/turbopack-07pt119epfd0-.js"
  ]
};

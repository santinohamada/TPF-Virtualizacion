globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/HB9eWy0zfv0I7g5UGbMQG/_buildManifest.js",
    "static/HB9eWy0zfv0I7g5UGbMQG/_ssgManifest.js",
    "static/HB9eWy0zfv0I7g5UGbMQG/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/02yc90psx--ft.js",
    "static/chunks/0cje14_narrpx.js",
    "static/chunks/0nls.c_8vefv8.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/turbopack-0nck_xl15op2b.js"
  ]
};
